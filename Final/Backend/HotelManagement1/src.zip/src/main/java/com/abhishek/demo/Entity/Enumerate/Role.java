package com.abhishek.demo.Entity.Enumerate;

public enum Role {
	USER,
	
	ADMIN

}