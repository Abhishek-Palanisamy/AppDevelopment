package com.hotelmanage.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotelmanage.main.Entity.AdminLoginEntity;

public interface AdminLoginRepository extends JpaRepository<AdminLoginEntity,Integer> {



}
