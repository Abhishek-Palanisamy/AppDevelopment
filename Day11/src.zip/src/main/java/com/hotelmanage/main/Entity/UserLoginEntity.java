package com.hotelmanage.main.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name="UserLogin")
public class UserLoginEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int UserLoginId;
	private String Username;
	private String Password;
	public UserLoginEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserLoginId() {
		return UserLoginId;
	}
	public void setUserLoginId(int userLoginId) {
		UserLoginId = userLoginId;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

}
